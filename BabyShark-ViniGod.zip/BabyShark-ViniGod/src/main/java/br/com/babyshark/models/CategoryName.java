package br.com.babyshark.models;

public enum CategoryName {
	
	

}
