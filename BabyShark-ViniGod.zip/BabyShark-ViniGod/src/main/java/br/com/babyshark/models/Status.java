package br.com.babyshark.models;

public enum Status {
	
	PENDENTE, ACEITO, RECUSADO

}
