package br.com.babyshark.dao;

import java.util.List;

import br.com.babyshark.models.Category;

public interface CategoryDAO {
	
	public List<Category> getAllCategories();

}
