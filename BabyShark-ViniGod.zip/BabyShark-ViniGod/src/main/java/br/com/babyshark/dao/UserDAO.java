package br.com.babyshark.dao;

public interface UserDAO {

}
